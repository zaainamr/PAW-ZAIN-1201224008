<?php
require "connect.php";

if (isset($_POST["create"])) {
    $judul          = $_POST["xjudul"];
    $penulis        = $_POST["xpenulis"];
    $penerbit       = $_POST["xpenerbit"];
    $tahun_terbit   = $_POST["xtahun_terbit"];
    $genre          = $_POST["xgenre"];
    $jumlah_halaman = $_POST["xjumlah_halaman"];
    $stok           = $_POST["xstok"];

    // Buat query INSERT ke tabel book_list menggunakan data dari form di atas.
    $query = "INSERT INTO buku (judul, penulis, penerbit, tahun_terbit, genre, jumlah_halaman, stok) 
              VALUES ('$judul', '$penulis', '$penerbit', '$tahun_terbit', '$genre', '$jumlah_halaman', '$stok')";
    mysqli_query($conn, $query);

    // Tambahkan pengecekan apakah data berhasil ditambahkan
    if (mysqli_affected_rows($conn) > 0) {
        echo "<script>alert('Data buku berhasil ditambahkan!');</script>";
        echo "<script>window.location.href = 'index.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan data buku!');</script>";
    }
}
?>

<?php
require "connect.php";

if (isset($_GET["id"])) {
    $id = $_GET["id"];

    // Buat query DELETE untuk menghapus data berdasarkan ID
    $query = "DELETE FROM buku WHERE id = $id";
    mysqli_query($conn, $query);

    // Tambahkan redirect ke list_buku.php setelah delete berhasil
    header("Location: list_buku.php");
    exit();
}

mysqli_close($conn);
?>
